<?php

namespace App\Http\Controllers;

use App\Models\shopping;
use Illuminate\Http\Request;


class ShoppingController 
{
    public function index(){
    	return shopping::all();
    }

    public function by_id($id){

    	return shopping::find($id);
    }

    public function create(request $request){

    	$shopping = new shopping ; 
    	$shopping->name= $request->name;
    	$shopping->save();

    	return "data Shopping Berhasil Disimpan";
    }

    public function update(request $request, $id){
    	$nama = $request->nama;
    	
    	$shopping = shopping::find($id);
    	$shopping->name= $request->name;
    	$shopping->save();
    	return "data Shopping Berhasil Diupdate";
    }

    public function delete($id){

    	$shopping = shopping::find($id);
    	$shopping->delete();

    	return "Data Berhasil Dihapus";
    }
}
