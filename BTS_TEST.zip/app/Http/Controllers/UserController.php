<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;


class UserController 
{
    public function index(){
    	return users::all();
    }

    public function create(request $request){

    	$users = new users ; 
    	$users->username= $request->username;
    	$users->password= $request->password;
    	$users->email= $request->email;
    	$users->phone= $request->phone;
    	$users->country= $request->country;
    	$users->city= $request->city;
    	$users->postcode= $request->postcode;
    	$users->name= $request->name;
    	$users->address= $request->address;
    	$users->save();

    	return "data users Berhasil Disimpan";
    }

}
